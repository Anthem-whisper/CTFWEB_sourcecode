<?php
class User{
    protected $username;
    protected $password;
    protected $admin;

    public function __construct($username, $password){
        $this->username = $username;
        $this->password = $password;
        $this->admin = 0;
    }

    public function get_admin(){
        return $this->admin;
    }
}


class Hacker_A{
    public $c2e38;

    public function __construct($c2e38){
        $this->c2e38 = $c2e38;
    }
    public function __destruct() {
        if(stristr($this->c2e38, "admin")===False){
            echo("must be admin");
        }else{
            echo("good luck");
        }
    }
}
class Hacker_B{
    public $c2e38;

    public function __construct($c2e38){
        $this->c2e38 = $c2e38;
    }

    public function get_c2e38(){
        return $this->c2e38;
    }

    public function __toString(){
        $tmp = $this->get_c2e38();
        $tmp();
        return 'test';
    }

}

class Hacker_C{
    public $name = 'test';

    public function __invoke(){
        var_dump(system('cat /flag'));
    }
}
