<?php

    return array(
        3 => array(//%42
            array("star" => "★★★", "name" => "kokodayo~", "type" => "狙击"),
            array("star" => "★★★", "name" => "泡普卡", "type" => "近卫"),
            array("star" => "★★★", "name" => "炎熔", "type" => "术士"),
            array("star" => "★★★", "name" => "斑点", "type" => "重装"),
            array("star" => "★★★", "name" => "香草", "type" => "先锋"),
            array("star" => "★★★", "name" => "粉毛猛男", "type" => "医疗"),
            array("star" => "★★★", "name" => "翎羽", "type" => "先锋"),
            array("star" => "★★★", "name" => "泡普卡", "type" => "近卫"),
            array("star" => "★★★", "name" => "卡缇", "type" => "重装"),
            array("star" => "★★★", "name" => "米格鲁", "type" => "重装"),
            array("star" => "★★★", "name" => "安德切尔", "type" => "狙击"),
            array("star" => "★★★", "name" => "芙蓉", "type" => "医疗"),
            array("star" => "★★★", "name" => "梓兰", "type" => "特种")
        ),
        4 => array(//%48
            array("star" => "★★★★", "name" => "NTR", "type" =>"重装"),
            array("star" => "★★★★", "name" => "孑哥", "type" =>"特种"),
            array("star" => "★★★★", "name" => "流泪富婆猫猫头", "type" =>"狙击"),
            array("star" => "★★★★", "name" => "你滴龟神", "type" =>"重装"),
            array("star" => "★★★★", "name" => "某法国干员", "type" =>"先锋"),
            array("star" => "★★★★", "name" => "某暴力医生", "type" =>"医疗"),
            array("star" => "★★★★", "name" => "台词烫嘴", "type" =>"特种"),
            array("star" => "★★★★", "name" => "FF0", "type" =>"医疗"),

        ),
        5 => array(//%8
            array("star" => "★★★★★", "name" => "玫剑圣", "type" => "近卫"),
            array("star" => "★★★★★", "name" => "不准你休息的驴", "type" => "术士/近卫"),
            array("star" => "★★★★★", "name" => "德克萨斯", "type" => "先锋"),
            array("star" => "★★★★★", "name" => "德克萨斯做得到吗", "type" => "近卫"),
        ) ,
        6 => array(//%2
            array("star" => "★★★★★★", "name" => "r4u的女朋友夕", "type" =>"术士"),
            array("star" => "★★★★★★", "name" => "r4u的老婆年", "type" =>"重装"),
            array("star" => "★★★★★★", "name" => "花泽香菜", "type" =>"重装"),
            array("star" => "★★★★★★", "name" => "推王", "type" =>"先锋"),
            array("star" => "★★★★★★", "name" => "蒂蒂", "type" =>"近卫"),
            array("star" => "★★★★★★", "name" => "小羊", "type" =>"术士"),
            array("star" => "★★★★★★", "name" => "银老板", "type" =>"近卫"),

        )
    );