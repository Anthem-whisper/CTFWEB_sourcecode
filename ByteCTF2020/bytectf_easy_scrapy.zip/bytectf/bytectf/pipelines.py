import pymongo

class BytectfPipeline:
 # 连接数据库
    def __init__(self):
    # 获取数据库连接信息
        MONGODB_HOST = '172.20.0.8'
        MONGODB_PORT = 27017
        MONGODB_DBNAME = 'result'
        MONGODB_TABLE = 'result'
        MONGODB_USER = 'N0rth3'
        MONGODB_PASSWD = 'E7B70D0456DAD39E22735E0AC64A69AD'
        mongo_client = pymongo.MongoClient("%s:%d" % (MONGODB_HOST, MONGODB_PORT))
        mongo_client[MONGODB_DBNAME].authenticate(MONGODB_USER, MONGODB_PASSWD, MONGODB_DBNAME)
        mongo_db = mongo_client[MONGODB_DBNAME]
        self.table = mongo_db[MONGODB_TABLE]


 # 处理item
    def process_item(self, item, spider):
        # 使用dict转换item，然后插入数据库
        quote_info = dict(item)
        print(quote_info)
        self.table.insert(quote_info)
        return item