@app.route('/')
def home():
    response = make_response(render_template("index.html"))
    response.headers['Set-Cookie'] = "token=WELCOME TO HGAME 2021.;"
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self';"
    return response


@app.route('/preview')
def preview():
    if session.get('substr'):
        substr = session['substr']
    else:
        substr = ""
    response = make_response(
        render_template("preview.html", substr=substr))
    return response


@app.route('/send', methods=['POST'])
def send():
    if request.form.get('content'):
        content = escape_index(request.form['content'])
        if session.get('contents'):
            content_list = session['contents']
            content_list.append(content)
        else:
            content_list = [content]
        session['contents'] = content_list
        return "post has been sent."
    else:
        return "WELCOME TO HGAME 2021 :)"


@app.route('/search', methods=["POST"])
def replace():
    if request.form.get('substr'):
        session['substr'] = escape_replace(request.form['substr'])
        return "replace success"
    else:
        return "There is no content to search any more"


@app.route('/contents', methods=["GET"])
def get_contents():
    if session.get('contents'):
        content_list = jsonify(session['contents'])
    else:
        content_list = jsonify('<i>2021-02-12</i><p>Happy New Year every guys! '
                               'Maybe it is nearly done now.</p>',
                               '<i>2021-02-11</i><p>Busy preparing for the Chinese New Year... '
                               'And I add some new features to this editor, maybe you can take a try. '
                               'But it has not done yet, I\'m not sure if it can be safe from attacks.</p>',
                               '<i>2021-02-07</i><p>so many hackers here, I am going to add some strict rules.</p>',
                               '<i>2021-02-06</i><p>I have tried to learn HTML the whole yesterday, '
                               'and I finally made this ONLINE BLOG EDITOR. Feel free to write down your thoughts.</p>',
                               '<i>2021-02-05</i><p>Yesterday, I watched <i>The Social Network</i>. '
                               'It really astonished me. Something flashed me.</p>')
    return content_list


@app.route('/code', methods=["GET"])
def get_code():
    if session.get('code'):
        return Response(response=json.dumps({'code': session['code']}), status=200, mimetype='application/json')
    else:
        code = create_code()
        session['code'] = code
        return Response(response=json.dumps({'code': code}), status=200, mimetype='application/json')


@app.route('/flag')
def show_flag():
    if request.cookies.get('token') == "29342ru89j3thisisfakecookieq983h23ijfq2ojifrnq92h2":
        return "hgame{G3t_fl@g_s0_Easy?No_way!!wryyyyyyyyy}"
    else:
        return "Only admin can get the flag, your token shows that you're not admin!"


@app.route('/clear')
def clear_session():
    session['contents'] = []
    return "ALL contents are cleared."


def escape_index(original):
    content = original
    content_iframe = re.sub(
        r"^(<?/?iframe)\s+.*?(src=[\"'][a-zA-Z/]{1,8}[\"']).*?(>?)$", r"\1 \2 \3", content)
    if content_iframe != content or re.match(r"^(<?/?iframe)\s+(src=[\"'][a-zA-Z/]{1,8}[\"'])$", content):
        return content_iframe
    else:
        content = re.sub(r"<*/?(.*?)>?", r"\1", content)
        return content


def escape_replace(original):
    content = original
    content = re.sub(r"[<>\"\\]", "", content)
    return content


def create_code():
    hashobj = hashlib.md5()
    hashobj.update(bytes(str(time.time()), encoding='utf-8'))
    code_hash = hashobj.hexdigest()[:6]
    return code_hash
