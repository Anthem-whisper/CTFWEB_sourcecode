Rogue-MySql-Server
==================

Edit script and change file to read and server port if you want. Run script and connect to your server for read file from client side. 
Read mysql.log for readed file content.
