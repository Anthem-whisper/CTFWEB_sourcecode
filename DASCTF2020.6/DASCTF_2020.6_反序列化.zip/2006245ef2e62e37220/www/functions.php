<?php
function redirect($path)
{
    header('Location: ' . $path);
    exit();
}

function add($data)
{
    $data = str_replace(chr(0).'*'.chr(0), '\0*\0', $data);
    return $data;
}

function reduce($data)
{
    $data = str_replace('\0*\0', chr(0).'*'.chr(0), $data);
    return $data;
}

function check($data)
{
    if(stristr($data, 'c2e38')!==False){
        die('exit');
    }
}