<?php
error_reporting(0);
require_once ("simulator.php");
$simulator = new Simulator();
$cards = array();
if(isset($_POST["draw"])){
    $cards = $simulator->draw($_POST["draw"]);
}
?>
<html lang="en">
<head>
    <title>Arknights</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="static/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/css/cover.css" rel="stylesheet">
</head>
<body class="text-center">
    <div class="d-flex w-100 h-100 p-3 mx-auto flex-column">
        <header class="mastfoot mt-auto">
            <h1>非酋证明器</h1>
            <br>
            <br>
        </header>

        <main style="height: 85%">
            <div class="card own">
                <h5 class="card-header" style="color: blue">抽中的六星干员</h5>
                <div class="card-body">
                    <?php
                        $legendary = $simulator->getLegendary();
                        foreach ($legendary as $worker){

                            echo "<p class='legendary'>".$worker["type"]." ".$worker["name"]."</p>";

                        }
                    ?>
                </div>
            </div>
            <div class="card col-md-3" style="color: #007bff;width=100%;">
                <h5 class="card-header">刀客塔，你要老婆不要？</h5>
                <div class="card-body">
                    <?php
                    if(!empty($cards)){
                        echo "<h5 class=\"card-title\">抽卡结果：</h5>";
                        echo "<br>";
                    }
                    foreach ($cards as $card){
                        switch ($card["stars"]){
                            case 3:
                                echo "<p class='normal'>".$card["card"]["star"]." ".$card["card"]["type"]." ".$card["card"]["name"]."</p>";
                                break;
                            case 4:
                                echo "<p class='rare'>".$card["card"]["star"]." ".$card["card"]["type"]." ".$card["card"]["name"]."</p>";
                                break;
                            case 5:
                                echo "<p class='epic'>".$card["card"]["star"]." ".$card["card"]["type"]." ".$card["card"]["name"]."</p>";
                                break;
                            case 6:
                                echo "<p class='legendary'>".$card["card"]["star"]." ".$card["card"]["type"]." ".$card["card"]["name"]."</p>";
                                break;
                        }
                    }
                    ?>
                    <br>
                    <hr>
                    <form method="POST" action="">
                        <button class="btn btn-primary" name="draw" value="1">抽一次</button>
                        <button class="btn btn-primary" name="draw" value="10">连连连连连连连连连连!</button>
                    </form>
                </div>
            </div>

        </main>
        <footer class="mastfoot mt-auto">
            <p>Made by 109发抽不到<del>老婆</del>夕的<b>R4u</b>.</p>
        </footer>
    </div>
</body>
</html>