<?php
require_once 'init.php';
require_once 'class.php';
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="static/css/index.css"/>
</head>
<body>

<form class="box" action="index.php" method="post">
    <h1>Login</h1>
    <input type="text" name="username" placeholder="e.g. a1b2c3d4">
    <input type="password" name="password" placeholder="password">
    <input type="submit" name="submit" value="Login">
</form>
</body>
</html>

<?php
if(isset($_POST['username']) && isset($_POST['password'])){
    $username = $_POST['username'];
    $password = $_POST['password'] ;
    $user = new User($username, $password);
    $_SESSION['info'] = add(serialize($user));

    redirect('info.php');
}