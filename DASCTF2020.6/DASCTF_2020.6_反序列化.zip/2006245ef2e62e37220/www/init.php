<?php
require_once 'functions.php';
error_reporting(0);
define('WORK_DIR' , getcwd());
session_save_path('session');
ini_set('session.serialize_handler','php');
session_start();
