<?php
require_once 'init.php';
require_once 'class.php';

check(reduce($_SESSION['info']));
$tmp = unserialize(reduce($_SESSION['info']));

if($tmp->get_admin() == 0){
    die('You must be admin');
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Info</title>
</head>
<body>
<h1> PHP unserialize </h1>

</body>
</html>
